package com.sergeyk.course.ws;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MobileWebAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
