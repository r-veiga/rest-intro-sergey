package com.sergeyk.course.ws;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MobileWebAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(MobileWebAppApplication.class, args);
	}

}
